# -*- coding: utf-8 -*-
"""Art error module."""


class artError(Exception):  # pragma: no cover
    """Art error class."""

    pass
