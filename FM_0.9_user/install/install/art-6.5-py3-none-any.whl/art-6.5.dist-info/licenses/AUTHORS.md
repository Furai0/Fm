# Core Developers

----------
- [@sepandhaghighi](http://github.com/sepandhaghighi) - Open Science Laboratory
- [@sadrasabouri](https://github.com/sadrasabouri) - Open Science Laboratory

# Other Contributors
----------
- [Arta Khanali](https://www.linkedin.com/in/artakhanali/) ++
- [@heidecjj](https://github.com/heidecjj)
- [@noobkoder](https://github.com/n00bkoder)
- [@codewithnick](https://github.com/codewithnick)
- [@eumiro](https://github.com/eumiro)
- [@AHReccese](https://github.com/AHReccese)
- [@wcupped](https://github.com/wcupped)


++ **Graphic designer**
